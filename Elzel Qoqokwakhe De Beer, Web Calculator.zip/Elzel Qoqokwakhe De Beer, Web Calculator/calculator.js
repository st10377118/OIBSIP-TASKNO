document.addEventListener('DOMContentLoaded', function () {
    const CalculatorScreen = document.getElementById('Calculator-screen');
    const buttons = document.querySelectorAll('.button');

    buttons.forEach(button => {
        button.addEventListener('click', () => {
            const action = button.dataset.action;
            const buttonContent = button.textContent;
            const displayedNum = CalculatorScreen.value;
            const previousKeyType = CalculatorScreen.dataset.previousKeyType;

            if (!action || action === 'number') {
                if (displayedNum === '0' || previousKeyType === 'operator' || previousKeyType === 'calculate') {
                    CalculatorScreen.value = buttonContent;
                } else {
                    CalculatorScreen.value = displayedNum + buttonContent;
                }
                CalculatorScreen.dataset.previousKeyType = 'number'; 
            }

            if (action === 'decimal') {
                if (!displayedNum.includes('.')) {
                    CalculatorScreen.value = displayedNum + '.';
                } else if (previousKeyType === 'operator' || previousKeyType === 'calculate') {
                    CalculatorScreen.value = '0.';
                }
                CalculatorScreen.dataset.previousKeyType = 'decimal';
            }

            if (action === 'operation') {
                if (CalculatorScreen.dataset.firstValue && previousKeyType !== 'operator' && previousKeyType !== 'calculate') {
                    const firstValue = CalculatorScreen.dataset.firstValue;
                    const operator = CalculatorScreen.dataset.operator;
                    const secondValue = displayedNum;
                    CalculatorScreen.value = calculate(firstValue, operator, secondValue);
                    CalculatorScreen.dataset.firstValue = CalculatorScreen.value;
                } else {
                    CalculatorScreen.dataset.firstValue = displayedNum; 
                }
                CalculatorScreen.dataset.previousKeyType = 'operator';
                CalculatorScreen.dataset.operator = buttonContent;
            }

            if (action === 'clear') {
                CalculatorScreen.value = '0';
                CalculatorScreen.dataset.firstValue = '';
                CalculatorScreen.dataset.operator = '';
                CalculatorScreen.dataset.previousKeyType = '';
            }

            if (action === 'delete') {
                CalculatorScreen.value = displayedNum.slice(0, -1);
                if (CalculatorScreen.value === '') {
                    CalculatorScreen.value = '0';
                }
                CalculatorScreen.dataset.previousKeyType = 'delete';
            }

            if (action === 'calculate') {
                const firstValue = CalculatorScreen.dataset.firstValue;
                const operator = CalculatorScreen.dataset.operator;
                const secondValue = displayedNum;

                if (firstValue && operator) {
                    CalculatorScreen.value = calculate(firstValue, operator, secondValue);
                }

                CalculatorScreen.dataset.previousKeyType = 'calculate';
                CalculatorScreen.dataset.firstValue = '';
                CalculatorScreen.dataset.operator = '';
            }
        });
    });

    function calculate(firstValue, operator, secondValue) {
        firstValue = parseFloat(firstValue);
        secondValue = parseFloat(secondValue);

        if (operator === '+') return firstValue + secondValue;
        if (operator === '-') return firstValue - secondValue;
        if (operator === '*') return firstValue * secondValue;
        if (operator === '/') return firstValue / secondValue;
        if (operator === '%') return firstValue % secondValue;
    }
});
